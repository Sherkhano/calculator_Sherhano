
let display = document.getElementById('display');
let currentInput = '';

function appendCharacter(char) {
    currentInput += char;
    display.value = currentInput;
}

function clearDisplay() {
    currentInput = '';
    display.value = '';
}

function calculateSquareRoot() {
  try {
      currentInput = Math.sqrt(eval(currentInput));
      display.value = currentInput;
  } catch (error) {
      display.value = 'Error';
  }
}

function calculateSquare() {
  try {
      currentInput = Math.pow(eval(currentInput), 2);
      display.value = currentInput;
  } catch (error) {
      display.value = 'Error';
  }
}


function calculateResult() {
    try {
        currentInput = eval(currentInput);
        display.value = currentInput;
    } catch (error) {
        display.value = 'Error';
    }
}
